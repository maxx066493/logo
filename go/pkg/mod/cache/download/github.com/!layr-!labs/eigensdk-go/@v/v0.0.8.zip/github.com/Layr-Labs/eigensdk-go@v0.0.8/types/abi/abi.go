package abi

import (
	_ "embed"
)

//go:embed BLSPublicKeyCompendium.json
var BLSPublicKeyCompendiumAbi []byte
