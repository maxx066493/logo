package utils

type BatchKey struct {
	PrivateKey string
	FilePath   string
	Password   string
}
