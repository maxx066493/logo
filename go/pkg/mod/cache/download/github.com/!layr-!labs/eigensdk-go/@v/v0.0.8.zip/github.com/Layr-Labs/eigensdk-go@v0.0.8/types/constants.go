package types

const EigenPromNamespace = "eigen"
