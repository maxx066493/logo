package signer

//go:generate mockgen -destination=./mocks/signer.go -package=mocks github.com/Layr-Labs/eigensdk-go/signer Signer
