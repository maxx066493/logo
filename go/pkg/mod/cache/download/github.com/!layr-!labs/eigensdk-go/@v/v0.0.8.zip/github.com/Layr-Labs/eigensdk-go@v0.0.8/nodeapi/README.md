# Node Api

This package implements the eigenlayer avs node spec [node-api](https://eigen.nethermind.io/docs/category/avs-node-api).

For an example of how to use this package, see [node-api-example](./nodeapi_example_test.go#L8)