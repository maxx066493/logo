# Eigen Metrics

This package implements the eigenlayer avs node spec [eigen metrics](https://eigen.nethermind.io/docs/category/metrics).

For an example of how to use this package, see [node-api-example](./eigenmetrics_example_test.go)