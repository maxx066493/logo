package logging

//go:generate mockgen -destination=mocks/mock_logger.go -package=mocks github.com/Layr-Labs/eigensdk-go/logging Logger
