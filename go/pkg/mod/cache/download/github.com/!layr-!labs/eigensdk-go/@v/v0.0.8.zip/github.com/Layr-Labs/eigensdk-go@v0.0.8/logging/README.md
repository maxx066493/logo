## Logging
We use Zap logger for this module

```
logger, err := NewZapLogger(env)
```