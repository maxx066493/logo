// Package common provides types, variables, constants and functions commonly used in SIDH or SIKE.
package common
