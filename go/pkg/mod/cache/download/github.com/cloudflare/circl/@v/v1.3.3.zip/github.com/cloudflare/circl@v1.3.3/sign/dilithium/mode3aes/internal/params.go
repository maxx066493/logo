// Code generated from params.templ.go. DO NOT EDIT.

package internal

const (
	Name          = "Dilithium3-AES"
	UseAES        = true
	K             = 6
	L             = 5
	Eta           = 4
	DoubleEtaBits = 4
	Omega         = 55
	Tau           = 49
	Gamma1Bits    = 19
	Gamma2        = 261888
)
