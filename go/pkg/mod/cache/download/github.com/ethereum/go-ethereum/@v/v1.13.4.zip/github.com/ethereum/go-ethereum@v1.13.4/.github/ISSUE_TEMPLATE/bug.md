---
name: Report a bug
about: Something with go-ethereum is not working as expected
title: ''
labels: 'type:bug'
assignees: ''
---

#### System information

Geth version: `geth version`
CL client & version: e.g. lighthouse/nimbus/prysm@v1.0.0
OS & Version: Windows/Linux/OSX
Commit hash : (if `develop`)

#### Expected behaviour


#### Actual behaviour


#### Steps to reproduce the behaviour


#### Backtrace

````
[backtrace]
````

When submitting logs: please submit them as text and not screenshots.
