package common

const (
	SpecVersion = "v0.1.0"
)
