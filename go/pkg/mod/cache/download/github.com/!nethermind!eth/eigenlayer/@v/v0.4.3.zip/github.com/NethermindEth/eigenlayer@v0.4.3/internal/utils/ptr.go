package utils

func StringPtr(s string) *string {
	return &s
}
