// The daemon package is responsible for providing all the functionalities for
// external API calls, like CLI or gRPC. The starting point is the Daemon interface.
package daemon
