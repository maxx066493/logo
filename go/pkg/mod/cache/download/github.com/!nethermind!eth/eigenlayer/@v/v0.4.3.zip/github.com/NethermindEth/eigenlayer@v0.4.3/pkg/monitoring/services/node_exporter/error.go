package node_exporter

import "errors"

var ErrInvalidOptions = errors.New("invalid options for grafana setup")
