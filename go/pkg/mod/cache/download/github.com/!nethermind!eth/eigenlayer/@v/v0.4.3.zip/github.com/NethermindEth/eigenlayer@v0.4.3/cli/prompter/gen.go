package prompter

//go:generate mockgen -destination=mocks/prompter.go -package=mocks github.com/NethermindEth/eigenlayer/cli/prompter Prompter
