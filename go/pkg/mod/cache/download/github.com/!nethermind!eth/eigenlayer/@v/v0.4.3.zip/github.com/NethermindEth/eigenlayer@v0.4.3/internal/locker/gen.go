package locker

//go:generate mockgen -package=mocks -destination=./mocks/locker.go github.com/NethermindEth/eigenlayer/internal/locker Locker
