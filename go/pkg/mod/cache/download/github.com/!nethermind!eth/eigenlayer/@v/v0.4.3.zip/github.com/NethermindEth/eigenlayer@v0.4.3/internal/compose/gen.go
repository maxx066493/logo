package compose

//go:generate mockgen -package=mocks -destination=./mocks/composeCmdRunner.go github.com/NethermindEth/eigenlayer/internal/compose CMDRunner
