//go:build !linux
// +build !linux

package capabilities
