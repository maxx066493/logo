// Package storage contains storage services for use in the registry
// application. It should be considered an internal package, as of Go 1.4.
package storage
