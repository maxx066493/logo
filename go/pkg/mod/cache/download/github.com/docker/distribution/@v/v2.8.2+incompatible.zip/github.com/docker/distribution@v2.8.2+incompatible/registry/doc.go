// Package registry provides the main entrypoints for running a registry.
package registry
