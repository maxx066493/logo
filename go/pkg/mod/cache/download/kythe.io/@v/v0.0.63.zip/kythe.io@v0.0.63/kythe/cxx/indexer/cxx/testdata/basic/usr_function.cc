// We index USRs for functions.

//- @foo defines/binding Foo
//- FooUsr /clang/usr Foo
//- FooUsr=vname(_,"","","","usr").node/kind clang/usr
void foo() { }
