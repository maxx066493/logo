#ifndef __arm__
#error not in ARM mode
#endif
void main() {}
