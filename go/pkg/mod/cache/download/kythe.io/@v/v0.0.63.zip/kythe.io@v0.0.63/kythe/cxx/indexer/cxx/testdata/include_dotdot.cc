#incdir emptydir
#include "../include_dotdot.h"
#example emptydir/.empty

#example include_dotdot.h

