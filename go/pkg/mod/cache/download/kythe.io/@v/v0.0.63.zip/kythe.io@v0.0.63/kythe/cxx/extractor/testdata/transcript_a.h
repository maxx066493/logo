#ifdef NEEDS_FEATURE_A
// evaluates the same
#endif
#ifdef NEEDS_FEATURE_B
// evaluates differently
#endif
