// Checks implicit-style (plain BCPL) juxtaposed documentation.

//- @:7"// doc1" documents Etor1
//- @:8"// doc2" documents Etor2

enum class C {
  E1,  // doc1
  E2   // doc2
};
