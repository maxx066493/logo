// We generate doc nodes for variables.

///- @x defines/binding VarX
int x;
///- Doc documents VarX
///- Doc.node/kind doc
///- Doc.text "- @x defines/binding VarX"
