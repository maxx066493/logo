// Comments avoid sticking to files where possible.
class C { };

//- MainFile=vname("","","","kythe/cxx/indexer/cxx/testdata/docs/docs_file_level_conflict.cc","").node/kind file
//- !{_ documents MainFile}
//- ClassC.node/kind record
//- Doc documents ClassC
//- Doc.text " Comments avoid sticking to files where possible."
