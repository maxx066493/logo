// We attach documentation to function templates.

//- @+2"/// Empty." documents Fun

/// Empty.
template <typename T> void f(T t) { }

//- Fun.node/kind function
