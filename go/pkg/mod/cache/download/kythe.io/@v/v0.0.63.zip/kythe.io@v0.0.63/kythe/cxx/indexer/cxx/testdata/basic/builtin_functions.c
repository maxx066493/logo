// Checks that we do the right thing with normal builtin functions.

int foo = strlen("hello");
