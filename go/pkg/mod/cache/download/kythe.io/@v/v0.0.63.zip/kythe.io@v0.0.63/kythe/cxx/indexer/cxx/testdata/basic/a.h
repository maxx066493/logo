#ifndef A_H_
#define A_H_
#endif  // A_H_