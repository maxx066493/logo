// A fake stdbool.h.
#define bool  bool
#define false false
#define true  true
