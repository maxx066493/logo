// Checks that the indexer finds and emits nodes for global static variables.
//- @x defines/binding VarNode
//- VarNode.node/kind variable
static int x;
