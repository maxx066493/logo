#include "gflags.h"

DECLARE_string(stringflag);
