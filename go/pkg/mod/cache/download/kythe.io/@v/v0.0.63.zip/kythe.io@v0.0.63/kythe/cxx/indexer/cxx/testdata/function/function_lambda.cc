// Checks basic behavior wrt recording lambdas (the indexer should not die).
auto L = []() -> void {};
