/// Test that `/kythe/build/config` is present on anchor nodes when
/// included in the compilation unit.

//- @fn.build/config "test-build-config"
void fn();
