// Test marked source for c++ classes.

//- @Foo defines/binding FooClass
//- FooClass code FooMSID
//- FooMSID.kind "IDENTIFIER"
//- FooMSID.pre_text "Foo"
class Foo {
};
