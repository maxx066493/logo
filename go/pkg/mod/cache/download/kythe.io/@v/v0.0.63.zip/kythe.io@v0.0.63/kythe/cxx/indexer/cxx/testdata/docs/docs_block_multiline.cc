// Block-style documentation comments are indexed.

//- ClassC.node/kind record
//- Doc.node/kind anchor
//- Doc.loc/start @^:9"/**"
//- Doc.loc/end @$:11"*/"
//- Doc documents ClassC

/**
  comment
 */
class C { };
