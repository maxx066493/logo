// Checks that function defns are recorded.
//- @f defines/binding FDefn
void f() { }
//- FDefn.node/kind function
//- FDefn.complete definition
