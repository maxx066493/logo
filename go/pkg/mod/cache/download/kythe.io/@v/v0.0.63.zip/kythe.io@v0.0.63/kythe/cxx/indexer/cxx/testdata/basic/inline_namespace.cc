// We index inline namespaces.
//- @ns ref NamespaceNS
//- NamespaceNS.node/kind package
inline namespace ns {
}
