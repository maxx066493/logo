//- @BinaryLiteral defines/binding LiteralVar
//- LiteralVar.node/kind variable
auto BinaryLiteral = 0b100'100;
