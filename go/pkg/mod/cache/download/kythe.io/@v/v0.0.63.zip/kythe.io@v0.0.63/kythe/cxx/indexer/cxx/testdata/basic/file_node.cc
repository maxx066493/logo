// Checks that the indexer emits file nodes.
//- vname("", "", "", "kythe/cxx/indexer/cxx/testdata/basic/file_node.cc", "")
//-   .node/kind file
