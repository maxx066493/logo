#ifdef KYTHE_IS_RUNNING
#pragma kythe_metadata "testdata/metadata.cc.meta"
#endif
