#ifdef MACRO
#define M
#endif
