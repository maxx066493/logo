// We keep track of namespace membership.
//- @ns ref NamespaceNS
namespace ns {
//- @x defines/binding VarX
  int x;
}
//- VarX childof NamespaceNS
