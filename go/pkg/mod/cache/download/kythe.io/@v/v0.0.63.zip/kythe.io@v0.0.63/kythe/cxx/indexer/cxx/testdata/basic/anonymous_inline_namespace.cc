// We index anonymous inline namespaces.
//- @namespace ref AnonymousInlineNS
//- AnonymousInlineNS.node/kind package
inline namespace {
}
