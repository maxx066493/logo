// We index anonymous namespaces.
//- @namespace ref AnonymousNamespace
//- AnonymousNamespace.node/kind package
namespace {
}
