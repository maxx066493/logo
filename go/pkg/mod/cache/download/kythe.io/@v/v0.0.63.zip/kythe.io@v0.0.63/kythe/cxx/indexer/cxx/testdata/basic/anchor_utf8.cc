int 錨;
//- Anchor=vname(_,Corpus,Root,Path,_).node/kind anchor
//- vname("",Corpus,Root,Path,"").node/kind file
//- Anchor.node/kind anchor
//- Anchor.loc/start 4
//- Anchor.loc/end 7
