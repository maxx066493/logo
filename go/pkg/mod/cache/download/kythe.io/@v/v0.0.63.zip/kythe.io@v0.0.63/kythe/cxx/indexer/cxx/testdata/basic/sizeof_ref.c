// We index references to types inside sizeof().
//- @float ref FloatType
//- FloatType.node/kind tbuiltin
int s = sizeof(float);
