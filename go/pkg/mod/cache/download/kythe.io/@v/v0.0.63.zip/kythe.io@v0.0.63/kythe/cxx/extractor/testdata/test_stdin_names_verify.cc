//- vname(_, "stdintest_pass", _, _, "").node/kind file
//- _MacroDef.node/kind macro
