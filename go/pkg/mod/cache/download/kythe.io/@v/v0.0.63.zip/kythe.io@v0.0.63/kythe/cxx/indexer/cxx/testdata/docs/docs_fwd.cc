// Documentation for forward declared classes is ignored.


//- !{@+4"/** doc */" documents ClassC}
//- ClassC.node/kind record
//- @+3"C" defines/binding ClassC

/** doc */
class C;
