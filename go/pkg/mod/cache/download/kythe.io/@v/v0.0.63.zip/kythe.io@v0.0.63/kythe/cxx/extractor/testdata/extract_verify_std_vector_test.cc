// Check that various template techniques used in std::vector don't cause smoke.
#include <vector>
std::vector<int> x(3, 4);
std::vector<bool> y;
