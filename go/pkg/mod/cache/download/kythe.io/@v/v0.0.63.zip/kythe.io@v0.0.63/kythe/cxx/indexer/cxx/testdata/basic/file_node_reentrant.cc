// Checks that the indexer emits file nodes only once.
#include "file_node_reentrant.h"
//- vname("", "", "",
//-   "kythe/cxx/indexer/cxx/testdata/basic/file_node_reentrant.h", "")
//-   .node/kind file
