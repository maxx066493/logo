// Checks that K&R-style function types (which lack prototypes/any parameter
// information) are properly recorded.
//- @F defines/binding FnF
//- FnF typed vname("knrfn#builtin",_,_,_,_)
int F();
