// Documentation can be placed next to documented elements.
enum class C {
//- @"///< an enumerator" documents EnumeratorCr
//- @Cr defines/binding EnumeratorCr
  Cr ///< an enumerator
};
