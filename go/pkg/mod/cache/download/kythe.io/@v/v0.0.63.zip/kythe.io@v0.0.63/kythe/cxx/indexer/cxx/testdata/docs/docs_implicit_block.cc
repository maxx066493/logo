// Checks implicit (plain BCPL) block comments.
//- @:4"// doc" documents ClassC

// doc
class C { };
