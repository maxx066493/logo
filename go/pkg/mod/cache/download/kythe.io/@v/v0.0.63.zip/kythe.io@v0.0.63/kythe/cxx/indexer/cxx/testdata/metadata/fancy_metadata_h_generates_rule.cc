// Checks that we can generate a generates edge.
#pragma kythe_metadata "fancy_single.meta.h"
//- vname(gsig, gcorp, groot, gpath, glang) generates VFoo
//- @foo defines/binding VFoo
int foo;
