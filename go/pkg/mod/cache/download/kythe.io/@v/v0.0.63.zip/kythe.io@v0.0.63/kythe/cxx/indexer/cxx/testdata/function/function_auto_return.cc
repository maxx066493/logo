// Functions can return auto.
//- @int ref IntType
int x;
//- @auto ref IntType
auto f() { return 42; }
