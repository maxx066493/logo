// BCPL-flavored block comments are indexed.

//- @:6"/// doc" documents ClassC
//- ClassC.node/kind record

/// doc
class C { };
