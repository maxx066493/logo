// Textual includes share the anonymous namespace.
#pragma kythe_claim
#include "header.inc"
//- @namespace ref CcNamespace
namespace { }

#example header.inc
#pragma kythe_claim
//- @namespace ref CcNamespace  // header ref
namespace { }
