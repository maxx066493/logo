// We index documentation for type alias templates.

//- @+2"/// Alias." documents Alias

/// Alias.
template<typename U>
using T = int;

//- Alias.node/kind talias
