// a header in a module named //foo
