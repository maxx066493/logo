#include "gflags.h"

DECLARE_bool(boolflag);
