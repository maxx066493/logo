#include <stddef.h>
//- @wchar_t ref _StddefWcharT
using StddefDefined = wchar_t;
