// Full definition ranges for free functions are recorded.

//- @"void f() { }" defines FnF
//- @f defines/binding FnF
void f() { }
