#ifdef NOT_MACRO
#define M
#endif
