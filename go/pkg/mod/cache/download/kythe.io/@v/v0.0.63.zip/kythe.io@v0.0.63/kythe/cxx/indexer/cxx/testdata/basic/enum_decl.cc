// Checks that enumerations are modeled with Sum nodes.
//- @E defines/binding EEnum
//- EEnum.node/kind sum
//- EEnum.complete definition
//- EEnum.subkind enum
enum E { };