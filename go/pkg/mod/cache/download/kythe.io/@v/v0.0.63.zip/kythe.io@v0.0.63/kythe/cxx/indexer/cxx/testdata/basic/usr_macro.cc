// We index USRs for macros.

//- @USR defines/binding UsrMacro
//- Usr=vname(_,"",_,_,_) /clang/usr UsrMacro
//- Usr.node/kind clang/usr
#define USR 1
