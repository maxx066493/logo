// Checks implicit (plain BCPL) multiline block comments.

//- Doc documents ClassC
//- Doc.loc/start @^:7"//"
//- Doc.loc/end @$:8"2"

// doc1
// doc2
class C { };
