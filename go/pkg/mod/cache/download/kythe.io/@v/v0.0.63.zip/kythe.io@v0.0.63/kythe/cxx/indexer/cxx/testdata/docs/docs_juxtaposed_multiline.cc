// Multiline documentation can be placed next to documented elements.

//- @:9Cr defines/binding EnumeratorCr
//- JxDoc documents EnumeratorCr
//- JxDoc.loc/start @^:9"///"
//- JxDoc.loc/end @$:11"enumerator"

enum class C {
  Cr ///< a
     ///< single
     ///< enumerator
};
