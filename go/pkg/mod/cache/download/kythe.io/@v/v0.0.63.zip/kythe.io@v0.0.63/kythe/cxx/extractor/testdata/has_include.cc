#if __has_include("has_include.h")
// ...
#else
#error "has_include failed"
#endif
