// Checks that function decls are recorded.
//- @f defines/binding FDecl
void f();
//- FDecl.node/kind function
//- FDecl.complete incomplete
