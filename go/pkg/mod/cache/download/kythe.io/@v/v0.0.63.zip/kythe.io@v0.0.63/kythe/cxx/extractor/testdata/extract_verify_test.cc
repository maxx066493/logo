//- @C defines/binding ClassC
//- ClassC.node/kind record
//- @C=vname(_,"kythe","","kythe/cxx/extractor/testdata/extract_verify_test.cc",_)
//-   .node/kind anchor
class C {};
