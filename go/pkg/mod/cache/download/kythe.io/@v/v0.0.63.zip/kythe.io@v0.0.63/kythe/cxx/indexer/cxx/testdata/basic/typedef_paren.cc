//- @tdef defines/binding TypeAlias
//- @"int" ref IntType
//- TypeAlias.node/kind talias
//- TypeAlias aliases IntType
typedef int (tdef);
